// import {Navbar,Nav,Container} from 'react-bootstrap'
import { Navbar } from 'react-bootstrap';
import Card from '../components/card'
import Catagorie from '../components/catagorie'
import Navbars from '../components/Navbar/Navbars'
import Sidebar from '../components/Sidebar/sidebar'
import Slide from '../components/Slideshow/imgslide'
function Home(){
    return ( 
        <>
        <Navbars></Navbars>
        </>
    )
    
}

 export default Home;
 