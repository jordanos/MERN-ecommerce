import Slide from '../components/Slideshow/imgslide'
import '../components/Slideshow/slidestyle.css'
import Gallery from '../components/Slideshow/slide2'
function Feeds(){
    return(
        
        <Gallery/>
    )
}

export default Feeds;