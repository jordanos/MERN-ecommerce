# Dashboard template

## Usage

<!-- #default-branch-switch -->

Copy the files into your project, or one of the [example projects](https://github.com/mui-org/material-ui/tree/master/examples), and import and use the `Dashboard` component.

## Demo

<!-- #default-branch-switch -->

View the demo at https://mui.com/getting-started/templates/dashboard/.
